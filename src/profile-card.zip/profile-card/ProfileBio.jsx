export default function ProfileBio({bio}){
    return (
        <p style={{color: "white", lineHeight: "1.4rem", textAlign: "justify"}}>{bio}</p>
    )
}