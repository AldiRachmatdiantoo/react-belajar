import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import ProfileContainer from './ProfileContainer'
import ProfileCard from './ProfileCard'
import ProfileName from './ProfileName'
import "./style.css"
import ProfileImage from './ProfileImage'
import ProfileBio from './ProfileBio'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ProfileContainer>
        <ProfileCard>
            <ProfileImage image={"/src/profile-card/WIN_20250720_14_13_28_Pro.jpg"}/>
            <ProfileName firstName={"Aldi"} lastName={"Rachmatdianto"}/>
            <ProfileBio bio={
                "Saya Aldi, 19 tahun, seorang developer yang suka mengembangkan aplikasi web dan mobile menggunakan React.js, Tailwind CSS, Flutter, Kotlin, React Native, dan Jetpack Compose, dengan fokus membangun aplikasi modern, responsif, dan user-friendly."
            }/>
        </ProfileCard>
    </ProfileContainer>
  </StrictMode>
)

