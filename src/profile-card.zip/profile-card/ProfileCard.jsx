import "./style.css"

export default function ProfileCard({children}){
    return(
        <div className="flexForParent card" style={{justifyContent: "flex-start"}}>
            {children}
        </div>
    )
}